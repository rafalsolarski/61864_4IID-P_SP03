﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projekt
{
    public partial class uzytkownik : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-QJ8J0NQM\SQLEXPRESS;Initial Catalog=Biblioteka;Trusted_Connection=True");
        string login, haslo, id;

        private void uzytkownik_Load(object sender, EventArgs e)
        {
            disp_data_wypo();
        }

        private void Wyjdz_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Dostepne_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Ksiazki where Wypozyczenie='0'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Twoje_Click(object sender, EventArgs e)
        {
            disp_data_wypo();
        }

        public uzytkownik(string log, string hasl)
        {
            InitializeComponent();
            login = log;
            haslo = hasl;
            label1.Text = "Login: " + login;
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Czytelnicy where Login='" + login + "'";
            cmd.ExecuteNonQuery();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                id = sdr.GetValue(0).ToString();
            }
            con.Close();


        }
        public void disp_data_wypo()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Ksiazki where Wypozyczenie = '"+id+"'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }           
}

