﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projekt
{
    public partial class Form1 : Form
    {
        public string log, hasl;
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-QJ8J0NQM\SQLEXPRESS;Initial Catalog=Biblioteka;Trusted_Connection=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        public void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                log = textBox1.Text;
                hasl = textBox2.Text;
                string loguj = "Select * from Czytelnicy Where login = '" + textBox1.Text.Trim() + "' and haslo = '" + textBox2.Text.Trim() + "'";
                SqlDataAdapter sda = new SqlDataAdapter(loguj, con);
                DataTable tabela = new DataTable();
                sda.Fill(tabela);
                if (tabela.Rows.Count == 1)
                {
                    Form uzytkownik = new uzytkownik(log, hasl);
                    this.Hide();
                    uzytkownik.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Błąd! Sprawdz wpisane dane", "UWAGA");
                }
            }
            else if (radioButton2.Checked)
            {
                if (textBox1.Text == "admin" && textBox2.Text == "admin1")
                {
                    Form admin = new admin();
                    this.Hide();
                    admin.ShowDialog();
                    this.Close();
                }
                else
                    MessageBox.Show("Błąd! Sprawdz wpisane dane", "UWAGA");

            }
            else
                MessageBox.Show("Błąd! Zaznacz CZYTELNIK lub ADMIN", "UWAGA");


        }

        
    }
}
