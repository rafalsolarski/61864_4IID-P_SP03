﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projekt
{
    public partial class admin : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-QJ8J0NQM\SQLEXPRESS;Initial Catalog=Biblioteka;Trusted_Connection=True");

        public admin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Czytelnicy values('" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','"+textBox9.Text+"','"+textBox10.Text+"')";
            cmd.ExecuteNonQuery();
            con.Close();           
            MessageBox.Show("Udało się! Dodałeś nowego czytelnika!", "Sukces!");
            disp_data_czytelnicy();

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";

        }
        
        public void disp_data_czytelnicy()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from czytelnicy";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close(); 
        }

        private void admin_Load(object sender, EventArgs e)
        {
            disp_data_czytelnicy();
        }

        private void usuń_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;

            if (radioButton1.Checked)
            {
                cmd.CommandText = "delete from czytelnicy where idczyt='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (radioButton2.Checked)
            {
                cmd.CommandText = "delete from czytelnicy where login='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (radioButton3.Checked)
            {
                cmd.CommandText = "delete from czytelnicy where Imie='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (radioButton4.Checked)
            {
                cmd.CommandText = "delete from czytelnicy where Nazwisko='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Zaznacz kryteria wyszukiwania!", "Błąd!");
            }           
            con.Close();
            disp_data_czytelnicy();
            textBox5.Text = "";
            MessageBox.Show("Wiersz usunięty", "Sukces");
        }

        private void zaktualizuj_Click(object sender, EventArgs e)
        {                      
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            string sdata;
            sdata = data_wypo.Text;
            if (sdata == "")
            {
                cmd.CommandText = "update ksiazki set Wypozyczenie = '" + ID_wypo.Text + "', DataWyp = NULL WHERE Tytul='" + tytul_wypo.Text + "'";
            }
            else
            {
                cmd.CommandText = "update ksiazki set Wypozyczenie = '" + ID_wypo.Text + "', DataWyp='" + data_wypo.Text+ "' WHERE Tytul='" + tytul_wypo.Text + "'";
            }
            cmd.ExecuteNonQuery();
            con.Close();
            disp_data_ksiazki();
            MessageBox.Show("Udało się! Zaktualizowałeś rekord!", "Sukces!");            
        }

        private void szukaj_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;

            if (radioButton1.Checked)
            {
                cmd.CommandText = "select * from Czytelnicy where idczyt='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (radioButton2.Checked)
            {
                cmd.CommandText = "select * from czytelnicy where login='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (radioButton3.Checked)
            {
                cmd.CommandText = "select * from czytelnicy where Imie='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (radioButton4.Checked)
            {
                cmd.CommandText = "select * from czytelnicy where Nazwisko='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Zaznacz kryteria wyszukiwania!", "Błąd!");
            }
            
            textBox5.Text = "";
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            disp_data_czytelnicy();
        }
        public void disp_data_ksiazki()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from ksiazki";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void dodaj_ksiazke_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into ksiazki values('" + textBox6.Text + "', '" + textBox7.Text + "','0',null)";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Udało się! Dodałeś nową książkę!", "Sukces!");
            disp_data_ksiazki();

            textBox6.Text = "";
            textBox7.Text = "";
        }

        private void wyswietl_ksiazki_Click(object sender, EventArgs e)
        {
            disp_data_ksiazki();
        }

        private void wyswietl_wypozyczone_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from ksiazki where Wypozyczenie!='0'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void szukaj_ksiazke_Click(object sender, EventArgs e)
        {
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;

                if (idksiazki.Checked)
                {
                    cmd.CommandText = "select * from ksiazki where idksiazki='" + textBox8.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                else if (Tytul.Checked)
                {
                    cmd.CommandText = "select * from ksiazki where Tytul='" + textBox8.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                else if (autor.Checked)
                {
                    cmd.CommandText = "select * from Ksiazki where Autor='" + textBox8.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                else if (wypozyczajacy.Checked)
                {
                    cmd.CommandText = "select * from Ksiazki where Wypozyczenie='" + textBox8.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Zaznacz kryteria wyszukiwania!", "Błąd!");                    
                }

                textBox8.Text = "";
                con.Close();
            }
        }

        private void usun_ksiazke_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;

            if (idksiazki.Checked)
            {
                cmd.CommandText = "delete from Ksiazki where idksiazki='" + textBox8.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (Tytul.Checked)
            {
                cmd.CommandText = "delete from ksiazki where Tytul='" + textBox8.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (autor.Checked)
            {
                cmd.CommandText = "delete from Ksiazki where Autor='" + textBox8.Text + "'";
                cmd.ExecuteNonQuery();
            }            
            else
            {
                MessageBox.Show("Zaznacz kryteria wyszukiwania!", "Błąd!");
            }
            con.Close();
            disp_data_ksiazki();
            textBox8.Text = "";
            MessageBox.Show("Ksiazka usunięta", "Sukces");
        }

        private void wyswietl_dostepne_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Ksiazki where Wypozyczenie='0'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
